const express = require('express')
const app = express()
const sdk = require('tellojs')

app.use(express.static('www'))
app.set('view engine', 'ejs')

app.get("/", (req, res) => {
    res.render("index")
    //Hello <%= locals.text || 'Default' %>
} )

/*const userRouter = require('./routers/users')
//const postRouter = require('./routers/posts')

app.use('/users', userRouter)
//app.use('/posts', postRouter) */

app.post('/connect', (req, res) => {
    console.log('it works');
    sdk.control.connect()
    let battery = sdk.read.battery()                      
    console.log(`Battery: ${battery}`)
    
    res.sendStatus(200);
});

app.listen(3000)