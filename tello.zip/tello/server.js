const express = require('express')
const app = express()

app.set('view engine', 'ejs')
app.get("/", (req, res) => {
    console.log("here")
    res.render("index", { text: "World"})
} )

const userRouter = require('./routers/users')
//const postRouter = require('./routers/posts')

app.use('/users', userRouter)
//app.use('/posts', postRouter) 


app.listen(3000)