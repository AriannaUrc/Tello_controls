function Connect(){
    console.log("JSSSS")
    fetch('/connect', {method: 'POST'})
}